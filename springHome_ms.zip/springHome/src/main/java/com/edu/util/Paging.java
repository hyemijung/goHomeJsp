package com.edu.util;

import java.io.Serializable;

public class Paging implements Serializable{
	
	public static final int PAGE_SCALE = 10;
	public static final int BLOCK_SCALE = 10;
	//PAGE, BLOCK 의 개념
	//page : row(1페이지 n명, 여기선 그 값이 10이니 10줄이 한페이지의 크기(scale)로 설정되어있음.)
	//block: 페이지 넘어가는 밑단의 1,2,3... 을 칭함. 1블럭당 10개의 rownum을 가지는데, 이 블럭의 값을 10개로 설정함
	
	
	/* 
	 page_scale = 한 페이지에 출력되는 rownum
	 block_scale = 한번에 보여주는 block의 갯수
	 curPage  : Current Page 현재 페이지, 내가 클릭한 페이지
	 prevPage : 2일때 1페이지
	 nextPage : 2일때 3페이지
	 totPage  : total page
	 totBlock : total page 에 관한 block 갯수
	 curBlock : 현재블럭
	 prevBlock: 이전블럭, <<
	 nextBlock: 다음블럭, >>
	 
	 pageBegin: db 들고올 실제 게시물 위치 시작
	 pageEnd  : db 들고올 실제 게시물 위치 끝
	 
	 blockBegin: 블록의 시작번호
	 blockEnd  : 블록의 끝번호
	  */
	
	
	
	 private int curPage;
	 private int prevPage;
	 private int nextPage;
	 private int totPage;
	 private int totBlock;
	 private int curBlock;
	 private int prevBlock;
	 private int nextBlock;
	 
	 private int pageBegin;	
	 private int pageEnd;
	
	 private int blockBegin;
	 private int blockEnd;
	 
	 
//	 curBlock : curPage가 1일 경우 1~10블럭.
//	 			curPage가 11일 경우 11~20블럭.
	 
	 //이건 단지 수많은 페이지 방식중 하나일 뿐
	 
	 						//curPage default = 1 임
	 public Paging(int count, int curPage) {
		this.curBlock = 1;
		this.curPage = curPage;
		setTotPage(count); //전체 페이지 개수
		setPageRange(); //
		setTotBlock();
		setBlockRange();
		//여기 처리는 db에서 할 수도 있고 여기서 할 수도 있고 그럿ㄱ스빈다..
	}
	 
	 
	 public void setPageRange() {
	 	pageBegin = (curPage - 1) * PAGE_SCALE + 1;
	 	pageEnd = pageBegin + PAGE_SCALE - 1;
	 //각 block의 페이지10개씩 뽑아주는 코드
	 }
	 
	 public void setBlockRange(){
		 curBlock = (int)Math.ceil((curPage - 1) / BLOCK_SCALE) + 1;
		 
		 blockBegin = (curBlock - 1) * BLOCK_SCALE + 1;
		 blockEnd = blockBegin + BLOCK_SCALE - 1;
		 
		 if (blockEnd > totPage) {
			blockEnd = totPage;
		}
		 
		 //삼항연산자는 if보다 100배(???)는 빠름!
		 prevPage = (curPage == 1) ? 1 : (curBlock - 1) * BLOCK_SCALE;
		 			//:을 기준으로 앞/뒤를 
		 nextPage = curBlock > totBlock ? (curBlock * BLOCK_SCALE)
				 	: (curBlock * BLOCK_SCALE) + 1;
		 //nextPage의 조건식은 이렇게쓰면 안된다~의 예시라 저렇게 적어놓은것.
		 //괄호로 꼭 표시해서 어디까지가 조건식인지 표시하기 ㅠㅠ 가독성 오져요 오져
		 
		 
		 //첫 페이지가 범위를 초과하지 않도록 처리
		 if (prevPage <= 0) {
			  prevPage = 1;
		}
		 
		 if (nextPage >= totPage) {
			  nextPage = totPage;
			
		}     
	 }
	 
	 
	 
	 
	public int getCurPage() {
		return curPage;
	}
	public void setCurPage(int curPage) {
		this.curPage = curPage;
	}
	public int getPrevPage() {
		return prevPage;
	}
	public void setPrevPage(int prevPage) {
		this.prevPage = prevPage;
	}
	public int getNextPage() {
		return nextPage;
	}
	public void setNextPage(int nextPage) {
		this.nextPage = nextPage;
	}
	public int getTotPage() {
		return totPage;
	}
	public void setTotPage(int count) {
		
		
		this.totPage = (int)Math.ceil(count * 1.0 / PAGE_SCALE);
	}
	public int getTotBlock() {
		return totBlock;
	}
	public void setTotBlock() {
		this.totBlock = (int)Math.ceil((double)totPage / (double)BLOCK_SCALE);
	}
	public int getCurBlock() {
		return curBlock;
	}
	public void setCurBlock(int curBlock) {
		this.curBlock = curBlock;
	}
	public int getPrevBlock() {
		return prevBlock;
	}
	public void setPrevBlock(int prevBlock) {
		this.prevBlock = prevBlock;
	}
	public int getNextBlock() {
		return nextBlock;
	}
	public void setNextBlock(int nextBlock) {
		this.nextBlock = nextBlock;
	}
	public int getPageBegin() {
		return pageBegin;
	}
	public void setPageBegin(int pageBegin) {
		this.pageBegin = pageBegin;
	}
	public int getPageEnd() {
		return pageEnd;
	}
	public void setPageEnd(int pageEnd) {
		this.pageEnd = pageEnd;
	}
	public int getBlockBegin() {
		return blockBegin;
	}
	public void setBlockBegin(int blockBegin) {
		this.blockBegin = blockBegin;
	}
	public int getBlockEnd() {
		return blockEnd;
	}
	public void setBlockEnd(int blockEnd) {
		this.blockEnd = blockEnd;
	}

	
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	
}

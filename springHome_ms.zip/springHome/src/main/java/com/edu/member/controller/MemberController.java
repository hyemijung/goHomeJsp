package com.edu.member.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.edu.member.service.MemberService;
import com.edu.member.vo.MemberVo;
import com.edu.util.Paging;

@Controller
public class MemberController {

	private static final Logger log = LoggerFactory.getLogger(MemberController.class);
	// class는 적으면 안되서 비슷한 clazz를 써놓음

	@Autowired
	private MemberService memberService;
//	 인스턴스 변수
//	 모든 메서드에서 다룰 수 잇음
//	 절대 지워지지 않는 특징을 가짐
//	 여기서 일처리를 하겠다는 하나의 선언?

	// 회원목록 조회 화면으로
	@RequestMapping(value = "/member/list.do",
					method = {RequestMethod.GET, RequestMethod.POST}) //get, post 둘다 처리
	public String memberList(
			@RequestParam(defaultValue="1")int curPage,
			@RequestParam(defaultValue="title")String searchOption,
			@RequestParam(defaultValue="")String keyword,
			Model model) {
		
		log.debug("Wecome MemberController memberList! : {}, {} ", curPage, searchOption);
		log.debug("{}", keyword);
		
		
		
		/*
		 * request.getParam이랑 같은 기능을 함(@RequestParam) 안에 값이 없으면 자동으로 1을 들고옴 curPage에
		 * 아무것도 안들고와도... 1이 들어가서 첫페이지가 보여진다는 말인가...? ==>그렇습니다
		 * 
		 * 간혹가다 getMembers 이런식으로 메서드명 지정하는 곳도 있음(getter/setter) memberListByNo,
		 * memberListByMno 이런식으로 프로젝트의 발전가능성을 멀리 본다면 신중히 작성해야함? 여기도 인터페이스 implement
		 * 받는경우도 있음 request의 기능을 model이 대신해줌. 쓸순있지만 자동으로 구현된거나 마찬가지라 안씀 model은 스프링이 준비해준
		 * 객체임(?) 컨트롤러는 무조건 service에 정보를 넘겨줌
		 */
		log.info("Welcome MemberController enter! ");
		
		int totalCount = memberService.memberSelectTotalCount(searchOption, keyword);
		//게시물 전체 개수 확인. 쪼개기 전(블럭에 담기 전) 전체 크기 파악(해야 쪼갤 수 있으니까)
		
		Paging memberPaging = new Paging(totalCount, curPage);
		int start = memberPaging.getPageBegin();
		int end = memberPaging.getPageEnd();
																//원래는 start end를 묶어야 함
		List<MemberVo> memberList = memberService.memberSelectList(
										searchOption, keyword, start, end); //10개 갖고옴
		
		Map<String, Object> pagingMap = new HashMap<>(); //모델 여러개 씀?
		pagingMap.put("totalCount", totalCount); //게시물의 갯수
		pagingMap.put("memberPaging", memberPaging); //
		

		model.addAttribute("memberList", memberList);
		model.addAttribute("pagingMap", pagingMap);
		model.addAttribute("keyword", keyword);
		model.addAttribute("searchOption", searchOption);
		// 데이터를 담아 전달할 것이 없어서 session안쓰고 model 씀??

		return "member/memberListView";
		// JUnit테스트 가능!
	}

	// 다양한 방법을 보여주기 위해 이상한(?) 짓 하는중.......?!?!?!?!?!!
	@RequestMapping(value = "/auth/login.do", method = RequestMethod.GET)
	public String login(HttpSession session, Model model) {
		log.debug("Welcome MemberController enter! ");
		// syso와 같은 역할
		
	
		

		return "auth/loginForm";
	}

	// 다양한 방법을 보여주기 위해 이상한(?) 짓 하는중.......?!?!?!?!?!!
	// map방식은 이런식으로 합니당 //value = 메서드의 시작 주소
	@RequestMapping(value = "/auth/loginCtr.do", method = RequestMethod.POST)
	// input 태그에서 받아온 값(name=email,password)들을 매개변수로 던져 받아옴
	public String loginCtr(String email, String password, HttpSession session, Model model) {
		// Model은 미래를 위해 만들어놓음
		// 지금은 홈으로 넘어가는거지만 앞으로는..!
		// 데이터를 그대로 다른 페이지로 전송하는 역할
		// request의 역할을 하고있음
		log.debug("Welcome MemberController enter! " + email + ", " + password);
		// syso와 같은 역할

		// 회사레벨에선 무조건 object임 나에게 맞춰 가변적으로 변화시키기위해서 object로..>!
		Map<String, Object> paramMap = new HashMap<>();
		paramMap.put("email", email);
		paramMap.put("pwd", password);
		// 2번째로 작성

		MemberVo memberVo = memberService.memberExist(paramMap); // <---f3말고 ctrl + 커서올리면
		// 여길 먼저 작성

		String viewUrl = "";

		if (memberVo != null) {
			// 회원이 존재한다면 세션에 담고
			// 회원 전체 조회 페이지로 이동
			session.setAttribute("_memberVo_", memberVo);
			// 세션을 연속?두번이상 setAttribute한다면 덮어씌워짐

			viewUrl = "redirect:/member/list.do";// 데이터파기 + 세션 유지
			// sendRedirect를 사용하는 방식 = redirect:
			// 돈(결제)과 관련된거였으면 바로 jsp로 보냄.
		} else {
			System.out.println("일단 안되는 걸로 치자");

//			viewUrl = "home";
			viewUrl = "/auth/loginFail";
		}

//		model.addAttribute("memberVo", memberVo); 
//		세션에 담는 redirect형태가 되었으니 필요가 없음

		// 앞에선 가져올 수 없었던 새로운 데이터를 다른 페이지로 전송!앞의 맥락과 일치
		// 모델에 데이터베이스를 직접 넣지는 않음?
		return viewUrl;
	}
	// 홈으로 일단 전달해보기
	// memberListView로 보내면 안됨!

	@RequestMapping(value = "/auth/logout.do", method = RequestMethod.GET)
	public String logout(HttpSession session, Model model) {
		log.debug("Welcome MemberController enter!  logout 페이지로 이동 !");

		// 세션의 객체들 파기
		session.invalidate();

		return "auth/loginForm";
	}

	@RequestMapping(value = "/member/add.do", method = RequestMethod.GET)
	public String memberAdd(HttpSession session, Model model) {
		log.debug("Welcome MemberController enter!  memberAdd 페이지로 이동 !");
		
		
		
		
		return "member/memberForm";
	}

	@RequestMapping(value = "/member/addCtr.do", method = RequestMethod.POST)
	public String memberAdd(MemberVo memberVo, MultipartHttpServletRequest multipartHttpServletRequest, Model model) {
		log.debug("Welcome MemberController enter!  memberAdd ! 신규등록 처리!" + memberVo);
		
		
		
		
		String url = "";
		
		
		try {
			memberService.memberInsertOne(memberVo, multipartHttpServletRequest);
			
			url = "redirect:/member/list.do";
		} catch (Exception e) {
			// TODO: handle exception
			
			return "auth/addFail";
			
		}
		

		return "redirect:/member/list.do";
		//redirect는 기존 데이터 파기시킴
	}

	@RequestMapping(value = "/member/listOne.do", method = RequestMethod.GET)
	public String memberListOne(int no, Model model) {

		log.info("Welcome MemberController enter! -{}", no);
		// c언어방식의 printF.... 블럭표시 하고 no 적으면 블럭 안에 no가 들어감!
		System.out.printf("{} 첫번째와 두번째에 변수 넣을수있음{}", "something", "behind");

		MemberVo memberVo = memberService.memberSelectOne(no);
		// int하나를 전달한다고 memberSelectOne에 객체를(memberVo타입) 전달하는건 비효율적
		// 하나만 뽑아쓰기 가능

		model.addAttribute("memberVo", memberVo);
		// 데이터를 담아 전달할 것이 없어서 session안쓰고 model 씀??
		// request 대신 쓰는듯. 어떤페이지로도 보낼 수 있음
		// 데이터를 담아 전달해야되서 model 씁니다,,,허헛,,흐히,,
		// 덕분에 형변환도 안해도 됩니다...!

		return "member/memberListOneView";
	}

	// meethod를 안써주면 자동적으로 post와 get을 결정해줌
	@RequestMapping(value = "/member/update.do", method = RequestMethod.GET)
	public String memberUpdate(int no, Model model) {

		log.info("Welcome MemberController enter! -{}" + no);

		MemberVo memberVo = memberService.memberSelectOne(no);
		// 기능의 분리! listOne메서드랑 같은거 갖고옴 ㅎ

		model.addAttribute("memberVo", memberVo);
		// 데이터를 담아 전달할 것이 없어서 session안쓰고 model 씀??

		return "member/memberUpdateForm";
	}

	@RequestMapping(value = "/member/updateCtr.do", method = RequestMethod.POST)
	public String memberUpdateCtr(HttpSession session, MemberVo memberVo, Model model) {
		log.debug("Welcome MemberController enter!  memberAdd ! 신규등록 처리!" + memberVo);

		int resultNum = memberService.memberUpdateOne(memberVo);
		// 한 사람이라도 변경(update)한다면 양수(1)가 됨. 이를 확인하기 위한 작업

		System.out.println("???????????" + resultNum);

//		session.setAttribute("_memberVo_", memberVo);

		// 원래..이렇게 하면..안됩니다...^^77
		//데이터베이스를 가져와서..?해야된다고 하시는데..
		//어떻게 하는지는 잘 모르곘습니다..ㅎ.,,ㅋ,ㅋ,,!
		//데이터베이스에서 회원정보가 수정이 되었는지 여부(0이상이면 수정된것)
		if (resultNum > 0) {
			MemberVo sessionMemberVo = (MemberVo) session.getAttribute("_memberVo_");
			//session은 기본적으로 map의 특징을 가짐
			//
			
			//비회원도 가능한 페이지를 거르기 위함?
			if (sessionMemberVo != null) {
				
				//login한 회원정보(sessionMemberVo)와 수정하기 위한 정보(memberVo)가 같은 지 여부
				if (sessionMemberVo.getNo() == memberVo.getNo()) {
					//변치않는 하나의 값으로 회원 판별하기 위해 no(기본키)를 활용했음
					// email, name, password, cre_date, mod_date 다 수정 가능하기때문에..?ㅎ
					
////					session.setAttribute("_memberVo_", memberVo);
//					
					MemberVo newMemberVo = new MemberVo();
//					깨끗한??객체 생성 시키기
//
					newMemberVo.setNo(memberVo.getNo());
					newMemberVo.setEmail(memberVo.getEmail());
					newMemberVo.setName(memberVo.getName());
					//3가지 정보만 들어감
					//3가지의 정보만 변했다는걸 시각적으로 인지하기 위해서?
					
//
////					session.invalidate();
					session.removeAttribute("_memberVo_");
//					// ?덮어쓰는게 아니었나
					// 가독성있게 만드는 방법
					// 
//
					session.setAttribute("_memberVo_", newMemberVo);
					
//					session.setAttribute("_memberVo_", memberVo);

				}
			}

		}

		return "common/successPage";
	}
	
	
	
	@RequestMapping(value = "/member/deleteCtr.do", method = RequestMethod.GET)
	public String memberDelete(@RequestParam(value="mno")int no, Model model) {
//		function pageMoveDeleteFnc(mno){
//		var url = 'deleteCtr.do?mno=' + mno; <--key=value
		//의 매개변수 이름을 자동치환?해줌
		//그냥 mno로 받아서 mno로 받아서 써도 되고, 이렇게 mno를 no로 치환해서 써도 되고. as you wish
		//근데 팀프할땐 좀 쓸거같음..ㅎ..!
		log.info("Welcome MemberController enter! 회원삭제처리 - {}" + no);

		memberService.memberDelete(no); //분명 값이 1일테니까 활용 가능함
		

//		model.addAttribute("memberVo", memberVo);
		// 데이터를 담아 전달할 것이 없어서 session안쓰고 model 씀??

		return "common/successPage";
//		return "redirect:/member/list.do";안먹히면 여기로 돌리기 ㅎ
	}
	
	
	@RequestMapping(value = "/member/td.do", method = RequestMethod.GET)
	public String memberTd( Model model) {
	
		
		return "td";
	}
	
//	ㅅㅐ로운거!새로운거!
	
	
	
	
	
	
	
	
	
	
	
	
	
}

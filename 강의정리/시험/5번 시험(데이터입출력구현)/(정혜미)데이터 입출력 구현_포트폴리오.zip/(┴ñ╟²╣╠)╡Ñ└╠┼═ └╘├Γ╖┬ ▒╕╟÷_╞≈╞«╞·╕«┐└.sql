


-- 조인하자 ( 팀 <-> 스타디움 <-> 스케쥴 )
select  std.stadium_name
        , sch.sche_date         
        , team_name                   AS HOMETEAM_NAME
        ,  sch.home_score       AS HOMETEAM_SCORE
        ,                                   AS AWAYTEAM_NAME
        , sch.away_score        AS AWAYTEAM_SCORE
from team t, stadium std, schedule sch 
where t.stadium_id=std.stadium_id
and std.stadium_id=sch.stadium_id
and sch.home_score is not null                                --홈팀점수와 (값이 없는 경기는 제외한다)                
and sch.away_score is not null                                --상대팀점수 둘 중 값이 없는 경기는 제외한다
order by sch_date desc, stadium_name asc;           --경기일정이 최근에 일어난 순서 및 경기장명을 사전순으로 정렬하시오





--팀 아이디로 팀 네임을 알수있다 -> 홈팀네임과  어웨이팀네임도 결국은 팀 아이디로 알수있다
-- 조인한 결과에서 홈팀네임과 상대팀네임을 어떻게 보여줄것인가?
-- 홈팀아이디 = 팀 아이디, 상대팀아이디 = 팀 아이디 ?
select team_name
from team
where team_id;




-- 날짜 형식 업데이트
update schedule
set sche_date = to_date('20120904', 'yyyy년mm월dd일');
where sche_date = '20120904';



-- 프로시저
 P_SEL_K_LEAGUE_SCHE('부산아시아드경기장', '20120904', V_STADIUM_NAME, V_SCHE_DATE, 
    V_HOMETEAM_NAME, V_HOMETEAM_SCORE, V_AWAYTEAM_NAME, V_AWAYTEAM_SCORE);
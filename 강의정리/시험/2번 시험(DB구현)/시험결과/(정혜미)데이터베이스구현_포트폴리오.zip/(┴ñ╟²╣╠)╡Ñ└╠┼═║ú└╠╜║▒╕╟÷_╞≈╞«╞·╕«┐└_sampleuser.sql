

select * from user_role_privs; 
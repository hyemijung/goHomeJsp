
create user sampleuser identified by sample12 account unlock;

grant connect to sampleuser;

grant resource to sampleuser;


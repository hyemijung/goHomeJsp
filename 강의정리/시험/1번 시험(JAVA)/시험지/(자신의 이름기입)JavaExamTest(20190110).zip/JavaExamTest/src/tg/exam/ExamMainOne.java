package tg.exam;

public class ExamMainOne {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// 1번 문제 정사각형 모양을 출력하기 - 사용자의 숫자 입력에 따라 높이와 넓이가 같은 정사각형을 출력
		
		

	}

}
